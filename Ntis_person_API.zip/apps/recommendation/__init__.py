"""Recommendation pipeline package."""

